from .normalize import normalize, UnsupportedInput

def entries(text):
    tokens = normalize(text)
    result = {}

    def scope(i, path, closing=False):
        seen = set()
        while i < len(tokens):
            token = tokens[i]
            if token == ("punctuation", "}"):
                if not closing:
                    raise UnsupportedInput("unexpected closing dictionary")
                return i + 1
            if token == ("punctuation", ";"):
                i += 1
                continue
            if token[0] not in ("word", "quoted"):
                raise UnsupportedInput("unsupported dictionary key")
            key = token[1]
            if token[0] == "quoted" and key[1:-1].replace("_", "").isalnum():
                # Literal quoted keys alias unquoted keys in OpenFOAM.
                key = key[1:-1]
            if key in seen:
                raise UnsupportedInput("duplicate dictionary key")
            seen.add(key)
            i += 1
            if key.startswith("#"):
                # Known include syntax is retained as an opaque entry, never executed.
                if key not in ("#include", "#includeIfPresent", "#includeEtc") or i >= len(tokens):
                    raise UnsupportedInput("unsupported directive")
                result[path + (key,)] = (tokens[i],)
                i += 1
                continue
            if i < len(tokens) and tokens[i] == ("punctuation", "{"):
                if key == "functions" and not path:
                    # Post-processing directives are opaque, not evaluated by
                    # defect assertions. Preserve every token without parsing
                    # repeated #includeFunc entries as duplicate dictionary keys.
                    start, depth = i, 1
                    i += 1
                    while i < len(tokens) and depth:
                        if tokens[i] == ("punctuation", "{"): depth += 1
                        if tokens[i] == ("punctuation", "}"): depth -= 1
                        i += 1
                    result[path + (key,)] = tokens[start:i]
                    continue
                result[path + (key,)] = ("dictionary",)
                i = scope(i + 1, path + (key,), True)
                continue
            start, depth = i, 0
            while i < len(tokens):
                t = tokens[i]
                if depth == 0 and t == ("punctuation", ";"):
                    break
                if depth == 0 and t == ("punctuation", "}"):
                    raise UnsupportedInput("entry missing semicolon")
                if t[0] == "punctuation":
                    if t[1] in "([{": depth += 1
                    elif t[1] in ")]}": depth -= 1
                i += 1
            if i == len(tokens):
                raise UnsupportedInput("unterminated dictionary entry")
            result[path + (key,)] = tokens[start:i]
            i += 1
        if closing:
            raise UnsupportedInput("unterminated dictionary")
        return i

    scope(0, ())
    return result


def viscosity_scalar(tokens):
    """v2306 dimensionedScalar nu: optional name/dimensions, exact scalar.

Only the known transportProperties/nu field uses this rule. Do not erase
dimensions globally or infer semantics for arbitrary dictionary entries.
Newtonian.C constructs nu with dimViscosity; dimensionedType::initialize
accepts omitted dimensions and rejects explicit incompatible dimensions.
"""
    tokens = tuple(tokens)
    if tokens and tokens[0][0] == "word" and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", tokens[0][1]):
        tokens = tokens[1:]
    dimensions = normalize("[0 2 -1 0 0 0 0]")
    if tokens[:len(dimensions)] == dimensions:
        tokens = tokens[len(dimensions):]
    return tokens[0] if len(tokens) == 1 and tokens[0][0] == "number" else None

