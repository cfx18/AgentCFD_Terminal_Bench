# s-001 — Transient Couette flow

## Public problem

See instruction.md for the full public specification and reporting contract.
This is the existing pilot task, not a new or harder question.

## Reference solution

solution/reference.py produces the qualification inputs. These are not starter
files and are never sent to a model. The formula in tests/analytic.py is private.

## Verification

tests/acceptance.py independently reads frozen native output. It checks public
physical constraints, velocity-profile accuracy and reported-number fidelity.
Numerical schemes are not compared literally with the reference configuration.
Tolerance and supported representations are unchanged by this migration.

## Execution

This package uses our durable native submission service, not stock `harbor run`.
task.toml follows Harbor's task layout; metadata.execution_protocol identifies
the extension. The service, rather than agent-authored files, owns run receipts.
No Docker image or fresh real-runtime qualification is claimed by packaging.
